package com.restaurant.api.service;

import com.restaurant.api.dto.order.*;
import com.restaurant.api.entity.*;
import com.restaurant.api.repository.DishRepository;
import com.restaurant.api.repository.OrderRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Service xử lý logic nghiệp vụ cho đơn hàng.
 */
@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final DishRepository dishRepository; // Đã có từ Module 2

    /**
     * Lấy danh sách tất cả đơn hàng.
     */
    @Transactional(readOnly = true)
    public List<OrderResponse> getAll() {
        return orderRepository.findAll()
                .stream()
                .map(this::toResponse)
                .toList();
    }

    /**
     * Lấy chi tiết 1 đơn hàng theo id.
     */
    @Transactional(readOnly = true)
    public OrderResponse getById(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Không tìm thấy đơn hàng với id = " + id));
        return toResponse(order);
    }

    /**
     * Tạo mới đơn hàng.
     */
    @Transactional
    public OrderResponse create(OrderCreateRequest request) {
        // Khởi tạo Order
        Order order = new Order();
        order.setCode(generateOrderCode()); // Mã đơn tự sinh
        order.setCustomerName(request.getCustomerName());
        order.setCustomerPhone(request.getCustomerPhone());
        order.setTableNumber(request.getTableNumber());
        order.setNote(request.getNote());
        order.setStatus(OrderStatus.PENDING); // Mặc định đơn mới là PENDING
        order.setCreatedBy("admin"); // Rule 54: tạm thời ghi cứng "admin"
        order.setCreatedAt(LocalDateTime.now());
        order.setUpdatedAt(LocalDateTime.now());

        BigDecimal totalAmount = BigDecimal.ZERO;

        // Nếu có danh sách món thì xử lý
        if (request.getItems() != null) {
            for (OrderItemRequest itemReq : request.getItems()) {
                // Lấy thông tin món từ DB
                Dish dish = dishRepository.findById(itemReq.getDishId())
                        .orElseThrow(() -> new EntityNotFoundException("Không tìm thấy món với id = " + itemReq.getDishId()));

                // Lấy giá tại thời điểm hiện tại
                BigDecimal price = dish.getPrice();
                Integer quantity = itemReq.getQuantity();
                BigDecimal amount = price.multiply(BigDecimal.valueOf(quantity));

                // Tạo OrderItem
                OrderItem orderItem = OrderItem.builder()
                        .dish(dish)
                        .quantity(quantity)
                        .price(price)
                        .amount(amount)
                        .build();

                // Gắn vào Order (quan hệ 2 chiều)
                order.addItem(orderItem);

                // Cộng dồn tổng tiền
                totalAmount = totalAmount.add(amount);
            }
        }

        order.setTotalAmount(totalAmount);

        // Lưu Order + OrderItem (nhờ cascade = ALL)
        Order saved = orderRepository.save(order);

        return toResponse(saved);
    }

    /**
     * Cập nhật thông tin đơn hàng.
     */
    @Transactional
    public OrderResponse update(Long id, OrderUpdateRequest request) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Không tìm thấy đơn hàng với id = " + id));

        // Cập nhật thông tin cơ bản
        order.setCustomerName(request.getCustomerName());
        order.setCustomerPhone(request.getCustomerPhone());
        order.setTableNumber(request.getTableNumber());
        order.setNote(request.getNote());

        // Cập nhật trạng thái nếu có gửi lên
        if (request.getStatus() != null) {
            order.setStatus(request.getStatus());
        }

        // Nếu FE gửi danh sách món mới -> thay toàn bộ
        if (request.getItems() != null) {
            // Xóa danh sách item cũ (orphanRemoval = true sẽ tự xóa trong DB)
            order.getItems().clear();

            BigDecimal totalAmount = BigDecimal.ZERO;

            for (OrderItemRequest itemReq : request.getItems()) {
                Dish dish = dishRepository.findById(itemReq.getDishId())
                        .orElseThrow(() -> new EntityNotFoundException("Không tìm thấy món với id = " + itemReq.getDishId()));

                BigDecimal price = dish.getPrice();
                Integer quantity = itemReq.getQuantity();
                BigDecimal amount = price.multiply(BigDecimal.valueOf(quantity));

                OrderItem orderItem = OrderItem.builder()
                        .dish(dish)
                        .quantity(quantity)
                        .price(price)
                        .amount(amount)
                        .build();

                order.addItem(orderItem);
                totalAmount = totalAmount.add(amount);
            }

            order.setTotalAmount(totalAmount);
        }

        // Cập nhật thời gian update
        order.setUpdatedAt(LocalDateTime.now());

        Order saved = orderRepository.save(order);

        return toResponse(saved);
    }

    /**
     * Xóa đơn hàng theo id.
     */
    @Transactional
    public void delete(Long id) {
        if (!orderRepository.existsById(id)) {
            throw new EntityNotFoundException("Không tìm thấy đơn hàng với id = " + id);
        }
        orderRepository.deleteById(id);
    }

    /**
     * Mapping từ Entity Order sang DTO OrderResponse.
     */
    private OrderResponse toResponse(Order order) {
        List<OrderItemResponse> itemResponses = order.getItems()
                .stream()
                .map(item -> OrderItemResponse.builder()
                        .id(item.getId())
                        .dishId(item.getDish().getId())
                        .dishName(item.getDish().getName())
                        .quantity(item.getQuantity())
                        .price(item.getPrice())
                        .amount(item.getAmount())
                        .build())
                .collect(Collectors.toList());

        return OrderResponse.builder()
                .id(order.getId())
                .code(order.getCode())
                .customerName(order.getCustomerName())
                .customerPhone(order.getCustomerPhone())
                .tableNumber(order.getTableNumber())
                .status(order.getStatus().name())
                .totalAmount(order.getTotalAmount())
                .note(order.getNote())
                .createdBy(order.getCreatedBy())
                .createdAt(order.getCreatedAt())
                .updatedAt(order.getUpdatedAt())
                .items(itemResponses)
                .build();
    }

    /**
     * Sinh mã đơn đơn giản dựa trên thời gian.
     * Có thể nâng cấp sau thành format đẹp hơn (ví dụ: ORD-20251124-0001).
     */
    private String generateOrderCode() {
        return "ORD-" + System.currentTimeMillis();
    }
}
