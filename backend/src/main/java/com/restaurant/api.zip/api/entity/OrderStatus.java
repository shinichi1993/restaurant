package com.restaurant.api.entity;

/**
 * Enum trạng thái đơn hàng.
 * Dùng để quản lý vòng đời của 1 Order.
 */
public enum OrderStatus {
    PENDING,   // Chờ xác nhận / mới tạo
    COOKING,   // Đang chế biến
    DONE,      // Hoàn thành, đã phục vụ xong
    CANCELLED  // Đã hủy
}
